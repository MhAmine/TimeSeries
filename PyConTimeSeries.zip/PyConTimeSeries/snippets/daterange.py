print(min(data.index))
print(max(data.index))