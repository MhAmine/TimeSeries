air_passengers.rolling(window = 20).var().plot()
