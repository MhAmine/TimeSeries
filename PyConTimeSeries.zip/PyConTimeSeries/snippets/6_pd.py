air_passengers = air_passengers.to_period()
